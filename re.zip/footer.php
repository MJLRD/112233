<link rel="stylesheet" href="_unified_assets/unified-style.css">
<script src="_unified_assets/unified-nav.js" defer></script>
</div> <!-- container -->
<footer class="bg-light text-center py-3 mt-4">
  <div>© MiSitio - Mejorado</div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<script src="scripts.js"></script>
</body>
</html>