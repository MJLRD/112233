<?php include 'header.php'; ?>
<div class="row">
  <div class="col-12">
    <div id="mainCarousel" class="carousel slide mb-4" data-bs-ride="carousel">
      <div class="carousel-inner">
        <div class="carousel-item active">
          <img src="assets/carousel1.jpg" class="d-block w-100" alt="Imagen 1">
        </div>
        <div class="carousel-item">
          <img src="assets/carousel2.jpg" class="d-block w-100" alt="Imagen 2">
        </div>
        <div class="carousel-item">
          <img src="assets/carousel3.jpg" class="d-block w-100" alt="Imagen 3">
        </div>
      </div>
      <button class="carousel-control-prev" type="button" data-bs-target="#mainCarousel" data-bs-slide="prev">
        <span class="carousel-control-prev-icon"></span>
      </button>
      <button class="carousel-control-next" type="button" data-bs-target="#mainCarousel" data-bs-slide="next">
        <span class="carousel-control-next-icon"></span>
      </button>
    </div>
  </div>
</div>

<div class="row">
  <div class="col-md-8">
    <div class="card p-3 mb-3">
      <h5>Bienvenido</h5>
      <p>Esta es tu página mejorada. El carrusel está ubicado en la parte superior, justo debajo del menú, porque así capta la atención sin interferir con la navegación.</p>
    </div>
  </div>
  <div class="col-md-4">
    <div class="card p-3 mb-3">
      <h6>Accesos rápidos</h6>
      <ul class="list-unstyled">
        <li><a href="login.php">Iniciar sesión</a></li>
        <li><a href="admin.php">Panel admin</a></li>
        <li><a href="users.php">Ver usuarios</a></li>
      </ul>
    </div>
  </div>
</div>

<?php include 'footer.php'; ?>