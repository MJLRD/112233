<?php include 'header.php'; ?>
<div class="card p-3">
  <h4>About Us</h4>
  <p>Este sitio fue mejorado automáticamente. Puedes adaptar los textos y estilos agregando contenido en los archivos.</p>
</div>
<?php include 'footer.php'; ?>