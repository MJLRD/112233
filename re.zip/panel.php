<?php
session_start();
include "db.php";

/* ============================================================
   BLOQUEO DE ACCESO SOLO PARA ADMINS
   ============================================================ */
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$alert = "";

/* ============================================================
   CREAR USUARIO O ADMIN
   ============================================================ */
if (isset($_POST['crear_usuario'])) {
    $username = trim($_POST['username']);
    $password_raw = trim($_POST['password']);
    $role = $_POST['role'];

    // Si quiere crear un admin → debe ingresar contraseña especial
    if ($role === "admin") {
        $clave_admin = $_POST["clave_admin"] ?? "";
        if ($clave_admin !== "FalloutNV") {
            $alert = "❌ Contraseña especial incorrecta. No puedes crear un ADMIN.";
        }
    }

    if (!$alert) {
        if (strlen($username) < 3 || strlen($username) > 10) {
            $alert = "El usuario debe tener entre 3 y 10 caracteres.";
        } elseif (strlen($password_raw) < 8) {
            $alert = "La contraseña debe tener mínimo 8 caracteres.";
        } else {
            $password = password_hash($password_raw, PASSWORD_DEFAULT);
            $stmt = $pdo->prepare("INSERT INTO users (username, password, role) VALUES (?, ?, ?)");
            $stmt->execute([$username, $password, $role]);
            $alert = "Usuario creado correctamente.";
        }
    }
}

/* ============================================================
   ELIMINAR USUARIO
   ============================================================ */
if (isset($_POST['eliminar_usuario'])) {
    $id = $_POST['user_id'];

    // Impedir que el admin se elimine a sí mismo
    if ($id == $_SESSION['user']['id']) {
        $alert = "❌ No puedes eliminar tu propia cuenta.";
    } else {
        $pdo->prepare("DELETE FROM users WHERE id=?")->execute([$id]);
        $alert = "Usuario eliminado.";
    }
}

/* ============================================================
   CAMBIAR ROL DEL USUARIO
   ============================================================ */
if (isset($_POST['cambiar_rol'])) {
    $id = $_POST['user_id'];
    $nuevo_rol = $_POST['nuevo_rol'];

    // Impedir que un admin se cambie su propio rol
    if ($id == $_SESSION['user']['id']) {
        $alert = "❌ No puedes cambiar tu propio rol.";
    } else {
        $pdo->prepare("UPDATE users SET role=? WHERE id=?")->execute([$nuevo_rol, $id]);
        $alert = "Rol actualizado.";
    }
}

/* ============================================================
   SUBIR IMAGEN AL CARRUSEL
   ============================================================ */
if (isset($_FILES['imagen_carrusel'])) {
    if ($_FILES['imagen_carrusel']['error'] === 0) {

        if (!is_dir("assets/carousel")) {
            mkdir("assets/carousel", 0777, true);
        }

        $nombre = time() . "_" . basename($_FILES['imagen_carrusel']['name']);
        $ruta = "assets/carousel/" . $nombre;

        move_uploaded_file($_FILES['imagen_carrusel']['tmp_name'], $ruta);

        $pdo->prepare("INSERT INTO carousel (imagen) VALUES (?)")->execute([$nombre]);
        $alert = "Imagen agregada al carrusel.";
    }
}

/* ============================================================
   ELIMINAR IMAGEN DEL CARRUSEL
   ============================================================ */
if (isset($_POST['eliminar_imagen'])) {
    $id = $_POST['img_id'];

    $stmt = $pdo->prepare("SELECT imagen FROM carousel WHERE id=?");
    $stmt->execute([$id]);
    $img = $stmt->fetchColumn();

    if ($img && file_exists("assets/carousel/" . $img)) {
        unlink("assets/carousel/" . $img);
    }

    $pdo->prepare("DELETE FROM carousel WHERE id=?")->execute([$id]);

    $alert = "Imagen eliminada.";
}

/* ============================================================
   OBTENER DATOS
   ============================================================ */
$usuarios = $pdo->query("SELECT * FROM users ORDER BY id ASC")->fetchAll(PDO::FETCH_ASSOC);
$imagenes = $pdo->query("SELECT * FROM carousel")->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Panel Admin | Book-Mastery</title>

  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body { background: #f5f6fa; color: #333; }

    .navbar-custom { background-color: #6c7ae0; }
    .navbar-custom .nav-link,
    .navbar-custom .navbar-brand { color: #fff !important; }

    .page-title {
      text-align: center; margin-top: 20px;
      font-size: 2rem; font-weight: bold; color: #4b4e6d;
    }

    .card-custom {
      background: #fff; border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
      padding: 20px;
    }

    #reloj {
      font-size: 1.3rem;
      font-weight: bold;
      color: #6c7ae0;
    }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-custom shadow-sm">
  <div class="container-fluid">
    <a class="navbar-brand" href="inicio_unificado.html">Book-Mastery</a>

    <div class="collapse navbar-collapse" id="navMain">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0"></ul>

      <span id="reloj" class="me-3"></span>

      <ul class="navbar-nav">
        <li class="nav-item"><a class="nav-link" href="logout.php">Cerrar sesión</a></li>
      </ul>
    </div>
  </div>
</nav>

<h1 class="page-title">Panel de Administración</h1>

<div class="container mt-4">

<?php if ($alert): ?>
<div class="alert alert-info text-center"><?= $alert ?></div>
<?php endif; ?>

<!-- ============================================================
     CREAR USUARIO / ADMIN
     ============================================================ -->
<div class="card-custom mb-4">
  <h4>Crear Usuario o Administrador</h4>
  <hr>

  <form method="POST" class="row g-3 mb-4">
    <input type="hidden" name="crear_usuario">

    <div class="col-md-3">
      <input type="text" name="username" class="form-control" placeholder="Usuario (3-10)" required>
    </div>

    <div class="col-md-3">
      <input type="password" name="password" class="form-control" placeholder="Contraseña (min 8)" required>
    </div>

    <div class="col-md-3">
      <select name="role" id="role" class="form-control" required onchange="mostrarClaveAdmin()">
        <option value="user">Usuario</option>
        <option value="admin">Administrador</option>
      </select>
    </div>

    <div class="col-md-3" id="clave_admin_div" style="display:none;">
      <input type="password" name="clave_admin" class="form-control" placeholder="Clave especial admin">
    </div>

    <div class="col-md-12">
      <button class="btn btn-primary w-100">Crear</button>
    </div>
  </form>

  <script>
  function mostrarClaveAdmin() {
      let rol = document.getElementById("role").value;
      document.getElementById("clave_admin_div").style.display =
          rol === "admin" ? "block" : "none";
  }
  </script>

  <!-- ============================================================
       TABLA DE USUARIOS
       ============================================================ -->
  <table class="table table-striped">
    <thead class="table-dark">
      <tr>
        <th>ID</th>
        <th>Usuario</th>
        <th>Rol</th>
        <th>Acciones</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($usuarios as $u): ?>
      <tr>
        <td><?= $u['id'] ?></td>
        <td><?= htmlspecialchars($u['username']) ?></td>
        <td><?= $u['role'] ?></td>
        <td>
          <div class="d-flex gap-2">

            <!-- Eliminar -->
            <form method="POST">
              <input type="hidden" name="eliminar_usuario">
              <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
              <button class="btn btn-danger btn-sm">Eliminar</button>
            </form>

            <!-- Cambiar rol -->
            <form method="POST">
              <input type="hidden" name="cambiar_rol">
              <input type="hidden" name="user_id" value="<?= $u['id'] ?>">

              <select name="nuevo_rol" class="form-select form-select-sm">
                <option value="user">User</option>
                <option value="admin">Admin</option>
              </select>

              <button class="btn btn-secondary btn-sm mt-1">Guardar</button>
            </form>

          </div>
        </td>
      </tr>
      <?php endforeach; ?>
    </tbody>
  </table>

</div>

<!-- ============================================================
     CARRUSEL DE IMÁGENES
     ============================================================ -->
<div class="card-custom mb-4">
  <h4>Modificar Carrusel de Imágenes</h4>
  <hr>

  <!-- Subir nueva imagen -->
  <form method="POST" enctype="multipart/form-data">
    <div class="input-group mb-3">
      <input type="file" name="imagen_carrusel" class="form-control" required>
      <button class="btn btn-success">Subir</button>
    </div>
  </form>

  <!-- Imágenes actuales -->
  <div class="row">
    <?php foreach ($imagenes as $img): ?>
    <div class="col-md-4 mb-3">
      <div class="card p-2">
        <img src="assets/carousel/<?= $img['imagen'] ?>"
             class="w-100" style="height:200px; object-fit:cover;">

        <form method="POST" class="mt-2">
          <input type="hidden" name="img_id" value="<?= $img['id'] ?>">
          <button name="eliminar_imagen" class="btn btn-danger w-100">Eliminar Imagen</button>
        </form>
      </div>
    </div>
    <?php endforeach; ?>
  </div>

</div>

</div>

<footer class="bg-light text-center py-3 mt-4">
  © 2025 Book-Mastery
</footer>

<script>
function actualizarReloj() {
    const ahora = new Date();
    document.getElementById("reloj").innerText =
        ahora.toLocaleTimeString("es-AR");
}
setInterval(actualizarReloj, 1000);
actualizarReloj();
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
